﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NightingaleHospice
{
	public partial class VolunteersInformation : Form
	{
		public VolunteersInformation()
		{
			InitializeComponent();
		}

		private void volunteersTableBindingNavigatorSaveItem_Click(object sender, EventArgs e)
		{
			this.Validate();
			this.volunteersTableBindingSource.EndEdit();
			this.tableAdapterManager.UpdateAll(this.volunteerInformationDataSet);

		}

		private void volunteersTableBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
		{
			this.Validate();
			this.volunteersTableBindingSource.EndEdit();
			this.tableAdapterManager.UpdateAll(this.volunteerInformationDataSet);

		}

		private void VolunteersInformation_Load(object sender, EventArgs e)
		{
			// TODO: This line of code loads data into the 'volunteerInformationDataSet.VolunteersTable' table. You can move, or remove it, as needed.
			this.volunteersTableTableAdapter.Fill(this.volunteerInformationDataSet.VolunteersTable);

		}

		private void radMale_CheckedChanged(object sender, EventArgs e)
		{
			if (radMale.Checked)
			{
				genderTextBox.Text = radMale.Text;
			}
		}

		private void radFemale_CheckedChanged(object sender, EventArgs e)
		{
			if(radFemale.Checked)
			{
				genderTextBox.Text = radFemale.Text;
			}
		}

		private void VolunteerPrevious_Click(object sender, EventArgs e)
		{
			volunteersTableBindingSource.MovePrevious();
		}

		private void VolunteerNext_Click(object sender, EventArgs e)
		{
			volunteersTableBindingSource.MoveNext();
		}

		private void VolunteerSubmit_Click(object sender, EventArgs e)
		{
			try
			{
				volunteersTableBindingSource.EndEdit();
				tableAdapterManager.UpdateAll(volunteerInformationDataSet);
				volunteerMessageBox("Record Submitted");
			}
			catch
			{
				volunteerMessageBox("Please recheck the field and try again");
			}
		}

		private void volunteerMessageBox(string v)
		{
			//throw new NotImplementedException();
		}

		private void VolunteerDelete_Click(object sender, EventArgs e)
		{
			volunteersTableBindingSource.RemoveCurrent();
			tableAdapterManager.UpdateAll(volunteerInformationDataSet);
			volunteerMessageBox("Current Record Deleted");
		}

		private void VolunteerNew_Click(object sender, EventArgs e)
		{
			volunteersTableBindingSource.AddNew();
			radMale.Checked = true;
		}

		private void VolunteerExit_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
