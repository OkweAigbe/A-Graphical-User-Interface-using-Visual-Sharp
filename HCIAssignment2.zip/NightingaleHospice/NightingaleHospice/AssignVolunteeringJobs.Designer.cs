﻿namespace NightingaleHospice
{
	partial class AssignVolunteeringJobs
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AssignVolunteeringJobs));
			System.Windows.Forms.Label iDLabel;
			System.Windows.Forms.Label job_DescriptionLabel;
			System.Windows.Forms.Label job_LocationLabel;
			System.Windows.Forms.Label addressLabel;
			System.Windows.Forms.Label skills_and_Training_RequiredLabel;
			System.Windows.Forms.Label start_DateLabel;
			System.Windows.Forms.Label end_DateLabel;
			System.Windows.Forms.Label job_AssignedLabel;
			System.Windows.Forms.Label volunteer_IDLabel;
			this.volunteeringJobsDataSet = new NightingaleHospice.VolunteeringJobsDataSet();
			this.volunteeringJobsTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.volunteeringJobsTableTableAdapter = new NightingaleHospice.VolunteeringJobsDataSetTableAdapters.VolunteeringJobsTableTableAdapter();
			this.tableAdapterManager = new NightingaleHospice.VolunteeringJobsDataSetTableAdapters.TableAdapterManager();
			this.volunteeringJobsTableBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
			this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
			this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
			this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
			this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
			this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
			this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
			this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
			this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
			this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
			this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
			this.volunteeringJobsTableBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
			this.iDTextBox = new System.Windows.Forms.TextBox();
			this.job_DescriptionTextBox = new System.Windows.Forms.TextBox();
			this.job_LocationTextBox = new System.Windows.Forms.TextBox();
			this.addressTextBox = new System.Windows.Forms.TextBox();
			this.skills_and_Training_RequiredTextBox = new System.Windows.Forms.TextBox();
			this.start_DateDateTimePicker = new System.Windows.Forms.DateTimePicker();
			this.end_DateDateTimePicker = new System.Windows.Forms.DateTimePicker();
			this.job_AssignedTextBox = new System.Windows.Forms.TextBox();
			this.volunteer_IDTextBox = new System.Windows.Forms.TextBox();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			iDLabel = new System.Windows.Forms.Label();
			job_DescriptionLabel = new System.Windows.Forms.Label();
			job_LocationLabel = new System.Windows.Forms.Label();
			addressLabel = new System.Windows.Forms.Label();
			skills_and_Training_RequiredLabel = new System.Windows.Forms.Label();
			start_DateLabel = new System.Windows.Forms.Label();
			end_DateLabel = new System.Windows.Forms.Label();
			job_AssignedLabel = new System.Windows.Forms.Label();
			volunteer_IDLabel = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.volunteeringJobsDataSet)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.volunteeringJobsTableBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.volunteeringJobsTableBindingNavigator)).BeginInit();
			this.volunteeringJobsTableBindingNavigator.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// volunteeringJobsDataSet
			// 
			this.volunteeringJobsDataSet.DataSetName = "VolunteeringJobsDataSet";
			this.volunteeringJobsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			// 
			// volunteeringJobsTableBindingSource
			// 
			this.volunteeringJobsTableBindingSource.DataMember = "VolunteeringJobsTable";
			this.volunteeringJobsTableBindingSource.DataSource = this.volunteeringJobsDataSet;
			// 
			// volunteeringJobsTableTableAdapter
			// 
			this.volunteeringJobsTableTableAdapter.ClearBeforeFill = true;
			// 
			// tableAdapterManager
			// 
			this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
			this.tableAdapterManager.UpdateOrder = NightingaleHospice.VolunteeringJobsDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
			this.tableAdapterManager.VolunteeringJobsTableTableAdapter = this.volunteeringJobsTableTableAdapter;
			// 
			// volunteeringJobsTableBindingNavigator
			// 
			this.volunteeringJobsTableBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
			this.volunteeringJobsTableBindingNavigator.BindingSource = this.volunteeringJobsTableBindingSource;
			this.volunteeringJobsTableBindingNavigator.CountItem = this.bindingNavigatorCountItem;
			this.volunteeringJobsTableBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
			this.volunteeringJobsTableBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.volunteeringJobsTableBindingNavigatorSaveItem});
			this.volunteeringJobsTableBindingNavigator.Location = new System.Drawing.Point(0, 0);
			this.volunteeringJobsTableBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
			this.volunteeringJobsTableBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
			this.volunteeringJobsTableBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
			this.volunteeringJobsTableBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
			this.volunteeringJobsTableBindingNavigator.Name = "volunteeringJobsTableBindingNavigator";
			this.volunteeringJobsTableBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
			this.volunteeringJobsTableBindingNavigator.Size = new System.Drawing.Size(1240, 25);
			this.volunteeringJobsTableBindingNavigator.TabIndex = 0;
			this.volunteeringJobsTableBindingNavigator.Text = "bindingNavigator1";
			// 
			// bindingNavigatorMoveFirstItem
			// 
			this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
			this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
			this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
			this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
			this.bindingNavigatorMoveFirstItem.Text = "Move first";
			// 
			// bindingNavigatorMovePreviousItem
			// 
			this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
			this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
			this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
			this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
			this.bindingNavigatorMovePreviousItem.Text = "Move previous";
			// 
			// bindingNavigatorSeparator
			// 
			this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
			this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
			// 
			// bindingNavigatorPositionItem
			// 
			this.bindingNavigatorPositionItem.AccessibleName = "Position";
			this.bindingNavigatorPositionItem.AutoSize = false;
			this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
			this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
			this.bindingNavigatorPositionItem.Text = "0";
			this.bindingNavigatorPositionItem.ToolTipText = "Current position";
			// 
			// bindingNavigatorCountItem
			// 
			this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
			this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
			this.bindingNavigatorCountItem.Text = "of {0}";
			this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
			// 
			// bindingNavigatorSeparator1
			// 
			this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
			this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
			// 
			// bindingNavigatorMoveNextItem
			// 
			this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
			this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
			this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
			this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
			this.bindingNavigatorMoveNextItem.Text = "Move next";
			// 
			// bindingNavigatorMoveLastItem
			// 
			this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
			this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
			this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
			this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
			this.bindingNavigatorMoveLastItem.Text = "Move last";
			// 
			// bindingNavigatorSeparator2
			// 
			this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
			this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
			// 
			// bindingNavigatorAddNewItem
			// 
			this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
			this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
			this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
			this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
			this.bindingNavigatorAddNewItem.Text = "Add new";
			// 
			// bindingNavigatorDeleteItem
			// 
			this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
			this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
			this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
			this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
			this.bindingNavigatorDeleteItem.Text = "Delete";
			// 
			// volunteeringJobsTableBindingNavigatorSaveItem
			// 
			this.volunteeringJobsTableBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.volunteeringJobsTableBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("volunteeringJobsTableBindingNavigatorSaveItem.Image")));
			this.volunteeringJobsTableBindingNavigatorSaveItem.Name = "volunteeringJobsTableBindingNavigatorSaveItem";
			this.volunteeringJobsTableBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
			this.volunteeringJobsTableBindingNavigatorSaveItem.Text = "Save Data";
			this.volunteeringJobsTableBindingNavigatorSaveItem.Click += new System.EventHandler(this.volunteeringJobsTableBindingNavigatorSaveItem_Click);
			// 
			// iDLabel
			// 
			iDLabel.AutoSize = true;
			iDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			iDLabel.Location = new System.Drawing.Point(358, 394);
			iDLabel.Name = "iDLabel";
			iDLabel.Size = new System.Drawing.Size(30, 20);
			iDLabel.TabIndex = 1;
			iDLabel.Text = "ID:";
			// 
			// iDTextBox
			// 
			this.iDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.volunteeringJobsTableBindingSource, "ID", true));
			this.iDTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.iDTextBox.Location = new System.Drawing.Point(654, 394);
			this.iDTextBox.Name = "iDTextBox";
			this.iDTextBox.Size = new System.Drawing.Size(200, 26);
			this.iDTextBox.TabIndex = 2;
			// 
			// job_DescriptionLabel
			// 
			job_DescriptionLabel.AutoSize = true;
			job_DescriptionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			job_DescriptionLabel.Location = new System.Drawing.Point(358, 420);
			job_DescriptionLabel.Name = "job_DescriptionLabel";
			job_DescriptionLabel.Size = new System.Drawing.Size(123, 20);
			job_DescriptionLabel.TabIndex = 3;
			job_DescriptionLabel.Text = "Job Description:";
			// 
			// job_DescriptionTextBox
			// 
			this.job_DescriptionTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.volunteeringJobsTableBindingSource, "Job Description", true));
			this.job_DescriptionTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.job_DescriptionTextBox.Location = new System.Drawing.Point(654, 420);
			this.job_DescriptionTextBox.Name = "job_DescriptionTextBox";
			this.job_DescriptionTextBox.Size = new System.Drawing.Size(200, 26);
			this.job_DescriptionTextBox.TabIndex = 4;
			// 
			// job_LocationLabel
			// 
			job_LocationLabel.AutoSize = true;
			job_LocationLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			job_LocationLabel.Location = new System.Drawing.Point(358, 446);
			job_LocationLabel.Name = "job_LocationLabel";
			job_LocationLabel.Size = new System.Drawing.Size(104, 20);
			job_LocationLabel.TabIndex = 5;
			job_LocationLabel.Text = "Job Location:";
			// 
			// job_LocationTextBox
			// 
			this.job_LocationTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.volunteeringJobsTableBindingSource, "Job Location", true));
			this.job_LocationTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.job_LocationTextBox.Location = new System.Drawing.Point(654, 446);
			this.job_LocationTextBox.Name = "job_LocationTextBox";
			this.job_LocationTextBox.Size = new System.Drawing.Size(200, 26);
			this.job_LocationTextBox.TabIndex = 6;
			// 
			// addressLabel
			// 
			addressLabel.AutoSize = true;
			addressLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			addressLabel.Location = new System.Drawing.Point(358, 472);
			addressLabel.Name = "addressLabel";
			addressLabel.Size = new System.Drawing.Size(72, 20);
			addressLabel.TabIndex = 7;
			addressLabel.Text = "Address:";
			// 
			// addressTextBox
			// 
			this.addressTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.volunteeringJobsTableBindingSource, "Address", true));
			this.addressTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.addressTextBox.Location = new System.Drawing.Point(654, 472);
			this.addressTextBox.Name = "addressTextBox";
			this.addressTextBox.Size = new System.Drawing.Size(200, 26);
			this.addressTextBox.TabIndex = 8;
			// 
			// skills_and_Training_RequiredLabel
			// 
			skills_and_Training_RequiredLabel.AutoSize = true;
			skills_and_Training_RequiredLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			skills_and_Training_RequiredLabel.Location = new System.Drawing.Point(358, 498);
			skills_and_Training_RequiredLabel.Name = "skills_and_Training_RequiredLabel";
			skills_and_Training_RequiredLabel.Size = new System.Drawing.Size(209, 20);
			skills_and_Training_RequiredLabel.TabIndex = 9;
			skills_and_Training_RequiredLabel.Text = "Skills and Training Required:";
			// 
			// skills_and_Training_RequiredTextBox
			// 
			this.skills_and_Training_RequiredTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.volunteeringJobsTableBindingSource, "Skills and Training Required", true));
			this.skills_and_Training_RequiredTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.skills_and_Training_RequiredTextBox.Location = new System.Drawing.Point(654, 498);
			this.skills_and_Training_RequiredTextBox.Name = "skills_and_Training_RequiredTextBox";
			this.skills_and_Training_RequiredTextBox.Size = new System.Drawing.Size(200, 26);
			this.skills_and_Training_RequiredTextBox.TabIndex = 10;
			// 
			// start_DateLabel
			// 
			start_DateLabel.AutoSize = true;
			start_DateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			start_DateLabel.Location = new System.Drawing.Point(358, 525);
			start_DateLabel.Name = "start_DateLabel";
			start_DateLabel.Size = new System.Drawing.Size(87, 20);
			start_DateLabel.TabIndex = 11;
			start_DateLabel.Text = "Start Date:";
			// 
			// start_DateDateTimePicker
			// 
			this.start_DateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.volunteeringJobsTableBindingSource, "Start Date", true));
			this.start_DateDateTimePicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.start_DateDateTimePicker.Location = new System.Drawing.Point(654, 524);
			this.start_DateDateTimePicker.Name = "start_DateDateTimePicker";
			this.start_DateDateTimePicker.Size = new System.Drawing.Size(200, 26);
			this.start_DateDateTimePicker.TabIndex = 12;
			// 
			// end_DateLabel
			// 
			end_DateLabel.AutoSize = true;
			end_DateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			end_DateLabel.Location = new System.Drawing.Point(358, 551);
			end_DateLabel.Name = "end_DateLabel";
			end_DateLabel.Size = new System.Drawing.Size(81, 20);
			end_DateLabel.TabIndex = 13;
			end_DateLabel.Text = "End Date:";
			// 
			// end_DateDateTimePicker
			// 
			this.end_DateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.volunteeringJobsTableBindingSource, "End Date", true));
			this.end_DateDateTimePicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.end_DateDateTimePicker.Location = new System.Drawing.Point(654, 550);
			this.end_DateDateTimePicker.Name = "end_DateDateTimePicker";
			this.end_DateDateTimePicker.Size = new System.Drawing.Size(200, 26);
			this.end_DateDateTimePicker.TabIndex = 14;
			// 
			// job_AssignedLabel
			// 
			job_AssignedLabel.AutoSize = true;
			job_AssignedLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			job_AssignedLabel.Location = new System.Drawing.Point(358, 576);
			job_AssignedLabel.Name = "job_AssignedLabel";
			job_AssignedLabel.Size = new System.Drawing.Size(109, 20);
			job_AssignedLabel.TabIndex = 15;
			job_AssignedLabel.Text = "Job Assigned:";
			// 
			// job_AssignedTextBox
			// 
			this.job_AssignedTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.volunteeringJobsTableBindingSource, "Job Assigned", true));
			this.job_AssignedTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.job_AssignedTextBox.Location = new System.Drawing.Point(654, 576);
			this.job_AssignedTextBox.Name = "job_AssignedTextBox";
			this.job_AssignedTextBox.Size = new System.Drawing.Size(200, 26);
			this.job_AssignedTextBox.TabIndex = 16;
			// 
			// volunteer_IDLabel
			// 
			volunteer_IDLabel.AutoSize = true;
			volunteer_IDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			volunteer_IDLabel.Location = new System.Drawing.Point(358, 602);
			volunteer_IDLabel.Name = "volunteer_IDLabel";
			volunteer_IDLabel.Size = new System.Drawing.Size(103, 20);
			volunteer_IDLabel.TabIndex = 17;
			volunteer_IDLabel.Text = "Volunteer ID:";
			// 
			// volunteer_IDTextBox
			// 
			this.volunteer_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.volunteeringJobsTableBindingSource, "Volunteer ID", true));
			this.volunteer_IDTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.volunteer_IDTextBox.Location = new System.Drawing.Point(654, 602);
			this.volunteer_IDTextBox.Name = "volunteer_IDTextBox";
			this.volunteer_IDTextBox.Size = new System.Drawing.Size(200, 26);
			this.volunteer_IDTextBox.TabIndex = 18;
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(27, 37);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(698, 206);
			this.pictureBox1.TabIndex = 19;
			this.pictureBox1.TabStop = false;
			// 
			// button1
			// 
			this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button1.Location = new System.Drawing.Point(406, 281);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 36);
			this.button1.TabIndex = 20;
			this.button1.Text = "New";
			this.button1.UseVisualStyleBackColor = true;
			// 
			// button2
			// 
			this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button2.Location = new System.Drawing.Point(579, 281);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(75, 36);
			this.button2.TabIndex = 21;
			this.button2.Text = "Edit";
			this.button2.UseVisualStyleBackColor = true;
			// 
			// button3
			// 
			this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button3.Location = new System.Drawing.Point(779, 281);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(75, 36);
			this.button3.TabIndex = 22;
			this.button3.Text = "Delete";
			this.button3.UseVisualStyleBackColor = true;
			// 
			// button4
			// 
			this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button4.Location = new System.Drawing.Point(451, 692);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(75, 41);
			this.button4.TabIndex = 23;
			this.button4.Text = "Submit";
			this.button4.UseVisualStyleBackColor = true;
			// 
			// button5
			// 
			this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button5.Location = new System.Drawing.Point(1005, 692);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(75, 41);
			this.button5.TabIndex = 24;
			this.button5.Text = "&Exit";
			this.button5.UseVisualStyleBackColor = true;
			this.button5.Click += new System.EventHandler(this.button5_Click);
			// 
			// AssignVolunteeringJobs
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1240, 764);
			this.Controls.Add(this.button5);
			this.Controls.Add(this.button4);
			this.Controls.Add(this.button3);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(iDLabel);
			this.Controls.Add(this.iDTextBox);
			this.Controls.Add(job_DescriptionLabel);
			this.Controls.Add(this.job_DescriptionTextBox);
			this.Controls.Add(job_LocationLabel);
			this.Controls.Add(this.job_LocationTextBox);
			this.Controls.Add(addressLabel);
			this.Controls.Add(this.addressTextBox);
			this.Controls.Add(skills_and_Training_RequiredLabel);
			this.Controls.Add(this.skills_and_Training_RequiredTextBox);
			this.Controls.Add(start_DateLabel);
			this.Controls.Add(this.start_DateDateTimePicker);
			this.Controls.Add(end_DateLabel);
			this.Controls.Add(this.end_DateDateTimePicker);
			this.Controls.Add(job_AssignedLabel);
			this.Controls.Add(this.job_AssignedTextBox);
			this.Controls.Add(volunteer_IDLabel);
			this.Controls.Add(this.volunteer_IDTextBox);
			this.Controls.Add(this.volunteeringJobsTableBindingNavigator);
			this.Name = "AssignVolunteeringJobs";
			this.Text = "AssignVolunteeringJobs";
			this.Load += new System.EventHandler(this.AssignVolunteeringJobs_Load);
			((System.ComponentModel.ISupportInitialize)(this.volunteeringJobsDataSet)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.volunteeringJobsTableBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.volunteeringJobsTableBindingNavigator)).EndInit();
			this.volunteeringJobsTableBindingNavigator.ResumeLayout(false);
			this.volunteeringJobsTableBindingNavigator.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private VolunteeringJobsDataSet volunteeringJobsDataSet;
		private System.Windows.Forms.BindingSource volunteeringJobsTableBindingSource;
		private VolunteeringJobsDataSetTableAdapters.VolunteeringJobsTableTableAdapter volunteeringJobsTableTableAdapter;
		private VolunteeringJobsDataSetTableAdapters.TableAdapterManager tableAdapterManager;
		private System.Windows.Forms.BindingNavigator volunteeringJobsTableBindingNavigator;
		private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
		private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
		private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
		private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
		private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
		private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
		private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
		private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
		private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
		private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
		private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
		private System.Windows.Forms.ToolStripButton volunteeringJobsTableBindingNavigatorSaveItem;
		private System.Windows.Forms.TextBox iDTextBox;
		private System.Windows.Forms.TextBox job_DescriptionTextBox;
		private System.Windows.Forms.TextBox job_LocationTextBox;
		private System.Windows.Forms.TextBox addressTextBox;
		private System.Windows.Forms.TextBox skills_and_Training_RequiredTextBox;
		private System.Windows.Forms.DateTimePicker start_DateDateTimePicker;
		private System.Windows.Forms.DateTimePicker end_DateDateTimePicker;
		private System.Windows.Forms.TextBox job_AssignedTextBox;
		private System.Windows.Forms.TextBox volunteer_IDTextBox;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button button5;
	}
}