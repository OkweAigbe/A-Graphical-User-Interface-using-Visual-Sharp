﻿namespace NightingaleHospice
{
	partial class VolunteersInformation
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.Label volunteerIDLabel;
			System.Windows.Forms.Label firstNameLabel;
			System.Windows.Forms.Label lastNameLabel;
			System.Windows.Forms.Label genderLabel;
			System.Windows.Forms.Label dateOfBirthLabel;
			System.Windows.Forms.Label addressLabel;
			System.Windows.Forms.Label telephone_NumberLabel;
			System.Windows.Forms.Label emailLabel;
			System.Windows.Forms.Label previous_ExperienceLabel;
			System.Windows.Forms.Label background_CheckedLabel;
			System.Windows.Forms.Label training_RecievedLabel;
			System.Windows.Forms.Label assigned_RoleLabel;
			System.Windows.Forms.Label locationLabel;
			System.Windows.Forms.Label preferred_CommunicationLabel;
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VolunteersInformation));
			this.volunteerInformationDataSet = new NightingaleHospice.VolunteerInformationDataSet();
			this.volunteersTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.volunteersTableTableAdapter = new NightingaleHospice.VolunteerInformationDataSetTableAdapters.VolunteersTableTableAdapter();
			this.tableAdapterManager = new NightingaleHospice.VolunteerInformationDataSetTableAdapters.TableAdapterManager();
			this.volunteersTableBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
			this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
			this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
			this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
			this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
			this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
			this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
			this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
			this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
			this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
			this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
			this.volunteersTableBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
			this.volunteerIDTextBox = new System.Windows.Forms.TextBox();
			this.firstNameTextBox = new System.Windows.Forms.TextBox();
			this.lastNameTextBox = new System.Windows.Forms.TextBox();
			this.genderTextBox = new System.Windows.Forms.TextBox();
			this.dateOfBirthDateTimePicker = new System.Windows.Forms.DateTimePicker();
			this.addressTextBox = new System.Windows.Forms.TextBox();
			this.telephone_NumberTextBox = new System.Windows.Forms.TextBox();
			this.emailTextBox = new System.Windows.Forms.TextBox();
			this.previous_ExperienceTextBox = new System.Windows.Forms.TextBox();
			this.background_CheckedTextBox = new System.Windows.Forms.TextBox();
			this.training_RecievedTextBox = new System.Windows.Forms.TextBox();
			this.assigned_RoleTextBox = new System.Windows.Forms.TextBox();
			this.locationTextBox = new System.Windows.Forms.TextBox();
			this.preferred_CommunicationTextBox = new System.Windows.Forms.TextBox();
			this.radMale = new System.Windows.Forms.RadioButton();
			this.radFemale = new System.Windows.Forms.RadioButton();
			this.VolunteerNew = new System.Windows.Forms.Button();
			this.VolunteerEdit = new System.Windows.Forms.Button();
			this.VolunteerDelete = new System.Windows.Forms.Button();
			this.VolunteerSubmit = new System.Windows.Forms.Button();
			this.VolunteerExit = new System.Windows.Forms.Button();
			this.VolunteerPrevious = new System.Windows.Forms.Button();
			this.VolunteerNext = new System.Windows.Forms.Button();
			volunteerIDLabel = new System.Windows.Forms.Label();
			firstNameLabel = new System.Windows.Forms.Label();
			lastNameLabel = new System.Windows.Forms.Label();
			genderLabel = new System.Windows.Forms.Label();
			dateOfBirthLabel = new System.Windows.Forms.Label();
			addressLabel = new System.Windows.Forms.Label();
			telephone_NumberLabel = new System.Windows.Forms.Label();
			emailLabel = new System.Windows.Forms.Label();
			previous_ExperienceLabel = new System.Windows.Forms.Label();
			background_CheckedLabel = new System.Windows.Forms.Label();
			training_RecievedLabel = new System.Windows.Forms.Label();
			assigned_RoleLabel = new System.Windows.Forms.Label();
			locationLabel = new System.Windows.Forms.Label();
			preferred_CommunicationLabel = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.volunteerInformationDataSet)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.volunteersTableBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.volunteersTableBindingNavigator)).BeginInit();
			this.volunteersTableBindingNavigator.SuspendLayout();
			this.SuspendLayout();
			// 
			// volunteerIDLabel
			// 
			volunteerIDLabel.AutoSize = true;
			volunteerIDLabel.Location = new System.Drawing.Point(180, 111);
			volunteerIDLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			volunteerIDLabel.Name = "volunteerIDLabel";
			volunteerIDLabel.Size = new System.Drawing.Size(103, 20);
			volunteerIDLabel.TabIndex = 1;
			volunteerIDLabel.Text = "Volunteer ID:";
			// 
			// firstNameLabel
			// 
			firstNameLabel.AutoSize = true;
			firstNameLabel.Location = new System.Drawing.Point(180, 151);
			firstNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			firstNameLabel.Name = "firstNameLabel";
			firstNameLabel.Size = new System.Drawing.Size(90, 20);
			firstNameLabel.TabIndex = 3;
			firstNameLabel.Text = "First Name:";
			// 
			// lastNameLabel
			// 
			lastNameLabel.AutoSize = true;
			lastNameLabel.Location = new System.Drawing.Point(180, 191);
			lastNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			lastNameLabel.Name = "lastNameLabel";
			lastNameLabel.Size = new System.Drawing.Size(90, 20);
			lastNameLabel.TabIndex = 5;
			lastNameLabel.Text = "Last Name:";
			// 
			// genderLabel
			// 
			genderLabel.AutoSize = true;
			genderLabel.Location = new System.Drawing.Point(180, 231);
			genderLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			genderLabel.Name = "genderLabel";
			genderLabel.Size = new System.Drawing.Size(67, 20);
			genderLabel.TabIndex = 7;
			genderLabel.Text = "Gender:";
			// 
			// dateOfBirthLabel
			// 
			dateOfBirthLabel.AutoSize = true;
			dateOfBirthLabel.Location = new System.Drawing.Point(180, 272);
			dateOfBirthLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			dateOfBirthLabel.Name = "dateOfBirthLabel";
			dateOfBirthLabel.Size = new System.Drawing.Size(106, 20);
			dateOfBirthLabel.TabIndex = 9;
			dateOfBirthLabel.Text = "Date Of Birth:";
			// 
			// addressLabel
			// 
			addressLabel.AutoSize = true;
			addressLabel.Location = new System.Drawing.Point(180, 311);
			addressLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			addressLabel.Name = "addressLabel";
			addressLabel.Size = new System.Drawing.Size(72, 20);
			addressLabel.TabIndex = 11;
			addressLabel.Text = "Address:";
			// 
			// telephone_NumberLabel
			// 
			telephone_NumberLabel.AutoSize = true;
			telephone_NumberLabel.Location = new System.Drawing.Point(180, 351);
			telephone_NumberLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			telephone_NumberLabel.Name = "telephone_NumberLabel";
			telephone_NumberLabel.Size = new System.Drawing.Size(148, 20);
			telephone_NumberLabel.TabIndex = 13;
			telephone_NumberLabel.Text = "Telephone Number:";
			// 
			// emailLabel
			// 
			emailLabel.AutoSize = true;
			emailLabel.Location = new System.Drawing.Point(180, 391);
			emailLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			emailLabel.Name = "emailLabel";
			emailLabel.Size = new System.Drawing.Size(52, 20);
			emailLabel.TabIndex = 15;
			emailLabel.Text = "Email:";
			// 
			// previous_ExperienceLabel
			// 
			previous_ExperienceLabel.AutoSize = true;
			previous_ExperienceLabel.Location = new System.Drawing.Point(180, 431);
			previous_ExperienceLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			previous_ExperienceLabel.Name = "previous_ExperienceLabel";
			previous_ExperienceLabel.Size = new System.Drawing.Size(156, 20);
			previous_ExperienceLabel.TabIndex = 17;
			previous_ExperienceLabel.Text = "Previous Experience:";
			// 
			// background_CheckedLabel
			// 
			background_CheckedLabel.AutoSize = true;
			background_CheckedLabel.Location = new System.Drawing.Point(180, 471);
			background_CheckedLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			background_CheckedLabel.Name = "background_CheckedLabel";
			background_CheckedLabel.Size = new System.Drawing.Size(166, 20);
			background_CheckedLabel.TabIndex = 19;
			background_CheckedLabel.Text = "Background Checked:";
			// 
			// training_RecievedLabel
			// 
			training_RecievedLabel.AutoSize = true;
			training_RecievedLabel.Location = new System.Drawing.Point(180, 511);
			training_RecievedLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			training_RecievedLabel.Name = "training_RecievedLabel";
			training_RecievedLabel.Size = new System.Drawing.Size(139, 20);
			training_RecievedLabel.TabIndex = 21;
			training_RecievedLabel.Text = "Training Recieved:";
			// 
			// assigned_RoleLabel
			// 
			assigned_RoleLabel.AutoSize = true;
			assigned_RoleLabel.Location = new System.Drawing.Point(180, 551);
			assigned_RoleLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			assigned_RoleLabel.Name = "assigned_RoleLabel";
			assigned_RoleLabel.Size = new System.Drawing.Size(116, 20);
			assigned_RoleLabel.TabIndex = 23;
			assigned_RoleLabel.Text = "Assigned Role:";
			// 
			// locationLabel
			// 
			locationLabel.AutoSize = true;
			locationLabel.Location = new System.Drawing.Point(180, 591);
			locationLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			locationLabel.Name = "locationLabel";
			locationLabel.Size = new System.Drawing.Size(74, 20);
			locationLabel.TabIndex = 25;
			locationLabel.Text = "Location:";
			// 
			// preferred_CommunicationLabel
			// 
			preferred_CommunicationLabel.AutoSize = true;
			preferred_CommunicationLabel.Location = new System.Drawing.Point(180, 631);
			preferred_CommunicationLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			preferred_CommunicationLabel.Name = "preferred_CommunicationLabel";
			preferred_CommunicationLabel.Size = new System.Drawing.Size(193, 20);
			preferred_CommunicationLabel.TabIndex = 27;
			preferred_CommunicationLabel.Text = "Preferred Communication:";
			// 
			// volunteerInformationDataSet
			// 
			this.volunteerInformationDataSet.DataSetName = "VolunteerInformationDataSet";
			this.volunteerInformationDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			// 
			// volunteersTableBindingSource
			// 
			this.volunteersTableBindingSource.DataMember = "VolunteersTable";
			this.volunteersTableBindingSource.DataSource = this.volunteerInformationDataSet;
			// 
			// volunteersTableTableAdapter
			// 
			this.volunteersTableTableAdapter.ClearBeforeFill = true;
			// 
			// tableAdapterManager
			// 
			this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
			this.tableAdapterManager.UpdateOrder = NightingaleHospice.VolunteerInformationDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
			this.tableAdapterManager.VolunteersTableTableAdapter = this.volunteersTableTableAdapter;
			// 
			// volunteersTableBindingNavigator
			// 
			this.volunteersTableBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
			this.volunteersTableBindingNavigator.BindingSource = this.volunteersTableBindingSource;
			this.volunteersTableBindingNavigator.CountItem = this.bindingNavigatorCountItem;
			this.volunteersTableBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
			this.volunteersTableBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.volunteersTableBindingNavigatorSaveItem});
			this.volunteersTableBindingNavigator.Location = new System.Drawing.Point(0, 0);
			this.volunteersTableBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
			this.volunteersTableBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
			this.volunteersTableBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
			this.volunteersTableBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
			this.volunteersTableBindingNavigator.Name = "volunteersTableBindingNavigator";
			this.volunteersTableBindingNavigator.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
			this.volunteersTableBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
			this.volunteersTableBindingNavigator.Size = new System.Drawing.Size(1476, 25);
			this.volunteersTableBindingNavigator.TabIndex = 0;
			this.volunteersTableBindingNavigator.Text = "bindingNavigator1";
			// 
			// bindingNavigatorAddNewItem
			// 
			this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
			this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
			this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
			this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
			this.bindingNavigatorAddNewItem.Text = "Add new";
			// 
			// bindingNavigatorCountItem
			// 
			this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
			this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
			this.bindingNavigatorCountItem.Text = "of {0}";
			this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
			// 
			// bindingNavigatorDeleteItem
			// 
			this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
			this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
			this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
			this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
			this.bindingNavigatorDeleteItem.Text = "Delete";
			// 
			// bindingNavigatorMoveFirstItem
			// 
			this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
			this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
			this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
			this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
			this.bindingNavigatorMoveFirstItem.Text = "Move first";
			// 
			// bindingNavigatorMovePreviousItem
			// 
			this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
			this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
			this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
			this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
			this.bindingNavigatorMovePreviousItem.Text = "Move previous";
			// 
			// bindingNavigatorSeparator
			// 
			this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
			this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
			// 
			// bindingNavigatorPositionItem
			// 
			this.bindingNavigatorPositionItem.AccessibleName = "Position";
			this.bindingNavigatorPositionItem.AutoSize = false;
			this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
			this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(73, 23);
			this.bindingNavigatorPositionItem.Text = "0";
			this.bindingNavigatorPositionItem.ToolTipText = "Current position";
			// 
			// bindingNavigatorSeparator1
			// 
			this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
			this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
			// 
			// bindingNavigatorMoveNextItem
			// 
			this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
			this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
			this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
			this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
			this.bindingNavigatorMoveNextItem.Text = "Move next";
			// 
			// bindingNavigatorMoveLastItem
			// 
			this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
			this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
			this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
			this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
			this.bindingNavigatorMoveLastItem.Text = "Move last";
			// 
			// bindingNavigatorSeparator2
			// 
			this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
			this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
			// 
			// volunteersTableBindingNavigatorSaveItem
			// 
			this.volunteersTableBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.volunteersTableBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("volunteersTableBindingNavigatorSaveItem.Image")));
			this.volunteersTableBindingNavigatorSaveItem.Name = "volunteersTableBindingNavigatorSaveItem";
			this.volunteersTableBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
			this.volunteersTableBindingNavigatorSaveItem.Text = "Save Data";
			this.volunteersTableBindingNavigatorSaveItem.Click += new System.EventHandler(this.volunteersTableBindingNavigatorSaveItem_Click_1);
			// 
			// volunteerIDTextBox
			// 
			this.volunteerIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.volunteersTableBindingSource, "VolunteerID", true));
			this.volunteerIDTextBox.Location = new System.Drawing.Point(381, 106);
			this.volunteerIDTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.volunteerIDTextBox.Name = "volunteerIDTextBox";
			this.volunteerIDTextBox.Size = new System.Drawing.Size(298, 26);
			this.volunteerIDTextBox.TabIndex = 2;
			// 
			// firstNameTextBox
			// 
			this.firstNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.volunteersTableBindingSource, "FirstName", true));
			this.firstNameTextBox.Location = new System.Drawing.Point(381, 146);
			this.firstNameTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.firstNameTextBox.Name = "firstNameTextBox";
			this.firstNameTextBox.Size = new System.Drawing.Size(298, 26);
			this.firstNameTextBox.TabIndex = 4;
			// 
			// lastNameTextBox
			// 
			this.lastNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.volunteersTableBindingSource, "LastName", true));
			this.lastNameTextBox.Location = new System.Drawing.Point(381, 186);
			this.lastNameTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.lastNameTextBox.Name = "lastNameTextBox";
			this.lastNameTextBox.Size = new System.Drawing.Size(298, 26);
			this.lastNameTextBox.TabIndex = 6;
			// 
			// genderTextBox
			// 
			this.genderTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.volunteersTableBindingSource, "Gender", true));
			this.genderTextBox.Location = new System.Drawing.Point(381, 226);
			this.genderTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.genderTextBox.Name = "genderTextBox";
			this.genderTextBox.Size = new System.Drawing.Size(88, 26);
			this.genderTextBox.TabIndex = 8;
			// 
			// dateOfBirthDateTimePicker
			// 
			this.dateOfBirthDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.volunteersTableBindingSource, "DateOfBirth", true));
			this.dateOfBirthDateTimePicker.Location = new System.Drawing.Point(381, 266);
			this.dateOfBirthDateTimePicker.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.dateOfBirthDateTimePicker.Name = "dateOfBirthDateTimePicker";
			this.dateOfBirthDateTimePicker.Size = new System.Drawing.Size(298, 26);
			this.dateOfBirthDateTimePicker.TabIndex = 10;
			// 
			// addressTextBox
			// 
			this.addressTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.volunteersTableBindingSource, "Address", true));
			this.addressTextBox.Location = new System.Drawing.Point(381, 306);
			this.addressTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.addressTextBox.Name = "addressTextBox";
			this.addressTextBox.Size = new System.Drawing.Size(298, 26);
			this.addressTextBox.TabIndex = 12;
			// 
			// telephone_NumberTextBox
			// 
			this.telephone_NumberTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.volunteersTableBindingSource, "Telephone Number", true));
			this.telephone_NumberTextBox.Location = new System.Drawing.Point(381, 346);
			this.telephone_NumberTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.telephone_NumberTextBox.Name = "telephone_NumberTextBox";
			this.telephone_NumberTextBox.Size = new System.Drawing.Size(298, 26);
			this.telephone_NumberTextBox.TabIndex = 14;
			// 
			// emailTextBox
			// 
			this.emailTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.volunteersTableBindingSource, "Email", true));
			this.emailTextBox.Location = new System.Drawing.Point(381, 386);
			this.emailTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.emailTextBox.Name = "emailTextBox";
			this.emailTextBox.Size = new System.Drawing.Size(298, 26);
			this.emailTextBox.TabIndex = 16;
			// 
			// previous_ExperienceTextBox
			// 
			this.previous_ExperienceTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.volunteersTableBindingSource, "Previous Experience", true));
			this.previous_ExperienceTextBox.Location = new System.Drawing.Point(381, 426);
			this.previous_ExperienceTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.previous_ExperienceTextBox.Name = "previous_ExperienceTextBox";
			this.previous_ExperienceTextBox.Size = new System.Drawing.Size(298, 26);
			this.previous_ExperienceTextBox.TabIndex = 18;
			// 
			// background_CheckedTextBox
			// 
			this.background_CheckedTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.volunteersTableBindingSource, "Background Checked", true));
			this.background_CheckedTextBox.Location = new System.Drawing.Point(381, 466);
			this.background_CheckedTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.background_CheckedTextBox.Name = "background_CheckedTextBox";
			this.background_CheckedTextBox.Size = new System.Drawing.Size(298, 26);
			this.background_CheckedTextBox.TabIndex = 20;
			// 
			// training_RecievedTextBox
			// 
			this.training_RecievedTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.volunteersTableBindingSource, "Training Recieved", true));
			this.training_RecievedTextBox.Location = new System.Drawing.Point(381, 506);
			this.training_RecievedTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.training_RecievedTextBox.Name = "training_RecievedTextBox";
			this.training_RecievedTextBox.Size = new System.Drawing.Size(298, 26);
			this.training_RecievedTextBox.TabIndex = 22;
			// 
			// assigned_RoleTextBox
			// 
			this.assigned_RoleTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.volunteersTableBindingSource, "Assigned Role", true));
			this.assigned_RoleTextBox.Location = new System.Drawing.Point(381, 546);
			this.assigned_RoleTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.assigned_RoleTextBox.Name = "assigned_RoleTextBox";
			this.assigned_RoleTextBox.Size = new System.Drawing.Size(298, 26);
			this.assigned_RoleTextBox.TabIndex = 24;
			// 
			// locationTextBox
			// 
			this.locationTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.volunteersTableBindingSource, "Location", true));
			this.locationTextBox.Location = new System.Drawing.Point(381, 586);
			this.locationTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.locationTextBox.Name = "locationTextBox";
			this.locationTextBox.Size = new System.Drawing.Size(298, 26);
			this.locationTextBox.TabIndex = 26;
			// 
			// preferred_CommunicationTextBox
			// 
			this.preferred_CommunicationTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.volunteersTableBindingSource, "Preferred Communication", true));
			this.preferred_CommunicationTextBox.Location = new System.Drawing.Point(381, 626);
			this.preferred_CommunicationTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.preferred_CommunicationTextBox.Name = "preferred_CommunicationTextBox";
			this.preferred_CommunicationTextBox.Size = new System.Drawing.Size(298, 26);
			this.preferred_CommunicationTextBox.TabIndex = 28;
			// 
			// radMale
			// 
			this.radMale.AutoSize = true;
			this.radMale.Location = new System.Drawing.Point(476, 226);
			this.radMale.Name = "radMale";
			this.radMale.Size = new System.Drawing.Size(61, 24);
			this.radMale.TabIndex = 29;
			this.radMale.TabStop = true;
			this.radMale.Text = "Male";
			this.radMale.UseVisualStyleBackColor = true;
			this.radMale.CheckedChanged += new System.EventHandler(this.radMale_CheckedChanged);
			// 
			// radFemale
			// 
			this.radFemale.AutoSize = true;
			this.radFemale.Location = new System.Drawing.Point(543, 226);
			this.radFemale.Name = "radFemale";
			this.radFemale.Size = new System.Drawing.Size(80, 24);
			this.radFemale.TabIndex = 30;
			this.radFemale.TabStop = true;
			this.radFemale.Text = "Female";
			this.radFemale.UseVisualStyleBackColor = true;
			this.radFemale.CheckedChanged += new System.EventHandler(this.radFemale_CheckedChanged);
			// 
			// VolunteerNew
			// 
			this.VolunteerNew.Location = new System.Drawing.Point(401, 40);
			this.VolunteerNew.Name = "VolunteerNew";
			this.VolunteerNew.Size = new System.Drawing.Size(109, 46);
			this.VolunteerNew.TabIndex = 31;
			this.VolunteerNew.Text = "&New";
			this.VolunteerNew.UseVisualStyleBackColor = true;
			this.VolunteerNew.Click += new System.EventHandler(this.VolunteerNew_Click);
			// 
			// VolunteerEdit
			// 
			this.VolunteerEdit.Location = new System.Drawing.Point(551, 40);
			this.VolunteerEdit.Name = "VolunteerEdit";
			this.VolunteerEdit.Size = new System.Drawing.Size(104, 46);
			this.VolunteerEdit.TabIndex = 32;
			this.VolunteerEdit.Text = "&Edit";
			this.VolunteerEdit.UseVisualStyleBackColor = true;
			// 
			// VolunteerDelete
			// 
			this.VolunteerDelete.Location = new System.Drawing.Point(696, 40);
			this.VolunteerDelete.Name = "VolunteerDelete";
			this.VolunteerDelete.Size = new System.Drawing.Size(107, 46);
			this.VolunteerDelete.TabIndex = 33;
			this.VolunteerDelete.Text = "&Delete";
			this.VolunteerDelete.UseVisualStyleBackColor = true;
			this.VolunteerDelete.Click += new System.EventHandler(this.VolunteerDelete_Click);
			// 
			// VolunteerSubmit
			// 
			this.VolunteerSubmit.Location = new System.Drawing.Point(456, 736);
			this.VolunteerSubmit.Name = "VolunteerSubmit";
			this.VolunteerSubmit.Size = new System.Drawing.Size(125, 63);
			this.VolunteerSubmit.TabIndex = 34;
			this.VolunteerSubmit.Text = "&Submit";
			this.VolunteerSubmit.UseVisualStyleBackColor = true;
			this.VolunteerSubmit.Click += new System.EventHandler(this.VolunteerSubmit_Click);
			// 
			// VolunteerExit
			// 
			this.VolunteerExit.Location = new System.Drawing.Point(1050, 736);
			this.VolunteerExit.Name = "VolunteerExit";
			this.VolunteerExit.Size = new System.Drawing.Size(124, 63);
			this.VolunteerExit.TabIndex = 35;
			this.VolunteerExit.Text = "&Exit";
			this.VolunteerExit.UseVisualStyleBackColor = true;
			this.VolunteerExit.Click += new System.EventHandler(this.VolunteerExit_Click);
			// 
			// VolunteerPrevious
			// 
			this.VolunteerPrevious.Location = new System.Drawing.Point(184, 736);
			this.VolunteerPrevious.Name = "VolunteerPrevious";
			this.VolunteerPrevious.Size = new System.Drawing.Size(135, 61);
			this.VolunteerPrevious.TabIndex = 36;
			this.VolunteerPrevious.Text = "<<<";
			this.VolunteerPrevious.UseVisualStyleBackColor = true;
			this.VolunteerPrevious.Click += new System.EventHandler(this.VolunteerPrevious_Click);
			// 
			// VolunteerNext
			// 
			this.VolunteerNext.Location = new System.Drawing.Point(778, 736);
			this.VolunteerNext.Name = "VolunteerNext";
			this.VolunteerNext.Size = new System.Drawing.Size(132, 61);
			this.VolunteerNext.TabIndex = 37;
			this.VolunteerNext.Text = ">>>";
			this.VolunteerNext.UseVisualStyleBackColor = true;
			this.VolunteerNext.Click += new System.EventHandler(this.VolunteerNext_Click);
			// 
			// VolunteersInformation
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1476, 948);
			this.Controls.Add(this.VolunteerNext);
			this.Controls.Add(this.VolunteerPrevious);
			this.Controls.Add(this.VolunteerExit);
			this.Controls.Add(this.VolunteerSubmit);
			this.Controls.Add(this.VolunteerDelete);
			this.Controls.Add(this.VolunteerEdit);
			this.Controls.Add(this.VolunteerNew);
			this.Controls.Add(this.radFemale);
			this.Controls.Add(this.radMale);
			this.Controls.Add(volunteerIDLabel);
			this.Controls.Add(this.volunteerIDTextBox);
			this.Controls.Add(firstNameLabel);
			this.Controls.Add(this.firstNameTextBox);
			this.Controls.Add(lastNameLabel);
			this.Controls.Add(this.lastNameTextBox);
			this.Controls.Add(genderLabel);
			this.Controls.Add(this.genderTextBox);
			this.Controls.Add(dateOfBirthLabel);
			this.Controls.Add(this.dateOfBirthDateTimePicker);
			this.Controls.Add(addressLabel);
			this.Controls.Add(this.addressTextBox);
			this.Controls.Add(telephone_NumberLabel);
			this.Controls.Add(this.telephone_NumberTextBox);
			this.Controls.Add(emailLabel);
			this.Controls.Add(this.emailTextBox);
			this.Controls.Add(previous_ExperienceLabel);
			this.Controls.Add(this.previous_ExperienceTextBox);
			this.Controls.Add(background_CheckedLabel);
			this.Controls.Add(this.background_CheckedTextBox);
			this.Controls.Add(training_RecievedLabel);
			this.Controls.Add(this.training_RecievedTextBox);
			this.Controls.Add(assigned_RoleLabel);
			this.Controls.Add(this.assigned_RoleTextBox);
			this.Controls.Add(locationLabel);
			this.Controls.Add(this.locationTextBox);
			this.Controls.Add(preferred_CommunicationLabel);
			this.Controls.Add(this.preferred_CommunicationTextBox);
			this.Controls.Add(this.volunteersTableBindingNavigator);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.Name = "VolunteersInformation";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "VolunteersInformation";
			this.Load += new System.EventHandler(this.VolunteersInformation_Load);
			((System.ComponentModel.ISupportInitialize)(this.volunteerInformationDataSet)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.volunteersTableBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.volunteersTableBindingNavigator)).EndInit();
			this.volunteersTableBindingNavigator.ResumeLayout(false);
			this.volunteersTableBindingNavigator.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private VolunteerInformationDataSet volunteerInformationDataSet;
		private System.Windows.Forms.BindingSource volunteersTableBindingSource;
		private VolunteerInformationDataSetTableAdapters.VolunteersTableTableAdapter volunteersTableTableAdapter;
		private VolunteerInformationDataSetTableAdapters.TableAdapterManager tableAdapterManager;
		private System.Windows.Forms.BindingNavigator volunteersTableBindingNavigator;
		private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
		private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
		private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
		private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
		private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
		private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
		private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
		private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
		private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
		private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
		private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
		private System.Windows.Forms.ToolStripButton volunteersTableBindingNavigatorSaveItem;
		private System.Windows.Forms.TextBox volunteerIDTextBox;
		private System.Windows.Forms.TextBox firstNameTextBox;
		private System.Windows.Forms.TextBox lastNameTextBox;
		private System.Windows.Forms.TextBox genderTextBox;
		private System.Windows.Forms.DateTimePicker dateOfBirthDateTimePicker;
		private System.Windows.Forms.TextBox addressTextBox;
		private System.Windows.Forms.TextBox telephone_NumberTextBox;
		private System.Windows.Forms.TextBox emailTextBox;
		private System.Windows.Forms.TextBox previous_ExperienceTextBox;
		private System.Windows.Forms.TextBox background_CheckedTextBox;
		private System.Windows.Forms.TextBox training_RecievedTextBox;
		private System.Windows.Forms.TextBox assigned_RoleTextBox;
		private System.Windows.Forms.TextBox locationTextBox;
		private System.Windows.Forms.TextBox preferred_CommunicationTextBox;
		private System.Windows.Forms.RadioButton radMale;
		private System.Windows.Forms.RadioButton radFemale;
		private System.Windows.Forms.Button VolunteerNew;
		private System.Windows.Forms.Button VolunteerEdit;
		private System.Windows.Forms.Button VolunteerDelete;
		private System.Windows.Forms.Button VolunteerSubmit;
		private System.Windows.Forms.Button VolunteerExit;
		private System.Windows.Forms.Button VolunteerPrevious;
		private System.Windows.Forms.Button VolunteerNext;
	}
}