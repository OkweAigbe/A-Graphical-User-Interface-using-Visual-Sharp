﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NightingaleHospice
{
	public partial class MainSwitchBoard : Form
	{
		public MainSwitchBoard()
		{
			InitializeComponent();
		}

		private void btnExit_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void MainManageVolunteerInfo_Click(object sender, EventArgs e)
		{
			new VolunteersInformation().Show();
		}

		private void MainManageVolunteeringJob_Click(object sender, EventArgs e)
		{
			new VolunteeringJobsInfo().Show();
		}

		private void MainAssignVolunteeringJob_Click(object sender, EventArgs e)
		{
			new AssignVolunteeringJobs().Show();
		}
	}
}
