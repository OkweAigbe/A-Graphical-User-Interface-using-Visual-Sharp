﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NightingaleHospice
{
	public partial class VolunteeringJobsInfo : Form
	{
		public VolunteeringJobsInfo()
		{
			InitializeComponent();
		}

		private void volunteeringJobsTableBindingNavigatorSaveItem_Click(object sender, EventArgs e)
		{
			this.Validate();
			this.volunteeringJobsTableBindingSource.EndEdit();
			this.tableAdapterManager.UpdateAll(this.volunteeringJobsDataSet);

		}

		private void VolunteeringJobsInfo_Load(object sender, EventArgs e)
		{
			// TODO: This line of code loads data into the 'volunteeringJobsDataSet.VolunteeringJobsTable' table. You can move, or remove it, as needed.
			this.volunteeringJobsTableTableAdapter.Fill(this.volunteeringJobsDataSet.VolunteeringJobsTable);

		}

		private void button4_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
